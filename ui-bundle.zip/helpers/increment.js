'use strict'

module.exports = (value) => (value || 0) + 1
